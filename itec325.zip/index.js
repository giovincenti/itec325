const express = require('express');
const app = express();
const port = 8325;

app.get('/', (req, res) => {
  res.send('Hello ITEC 325!');
});

app.get('/temp/', (req, res) => {
  let temp_in = 0;
  let temp_out = 0;
  let valid = false;
  
  if(req.query.tempc) {
    valid=true;
    temp_in = req.query.tempc;
    temp_out = (temp_in * 9 / 5)+32;
    res.send(JSON.stringify({"c":temp_in,"f":temp_out}));
  }
  
  if(req.query.tempf) {
    valid=true;
    temp_in = req.query.tempf;
    temp_out = (temp_in - 32) * 5 / 9;
    res.send(JSON.stringify({"f":temp_in,"c":temp_out}));
  }
  
  if (!valid) {
    res.send({"Error":"Please utilize the service properly"});
  }
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
